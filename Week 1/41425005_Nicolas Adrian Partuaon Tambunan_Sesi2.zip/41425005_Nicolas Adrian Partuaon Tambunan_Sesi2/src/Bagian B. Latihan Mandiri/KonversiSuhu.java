
import java.util.Scanner;


public class KonversiSuhu {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Masukkan suhu dalam Celsius: ");
        double celsius = input.nextDouble();
        double fahrenheit = (celsius * 9 / 5) + 32;
        System.out.println(celsius + " C = " + fahrenheit + " F");

        System.out.print("Masukkan suhu dalam Fahrenheit: ");
        double fahrenheit2 = input.nextDouble();
        double celsius2 = (fahrenheit2 - 32) * 5 / 9;
        System.out.printf("%.1f F = %.2f C%n", fahrenheit2, celsius2);
    }
}
//Nama : Nicolas adrian partuaon Tambunan
//Nim  : 41425005
//Prodi : Strpl-1